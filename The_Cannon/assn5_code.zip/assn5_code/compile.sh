g++ main.cpp board.cpp soldier.cpp townhall.cpp functions.cpp action.cpp minimax_ids.cpp transposition_table.cpp zobrist.cpp -O3 -std=c++11
